import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner input1 = new Scanner(System.in);
        int randomNum = random.nextInt(100);
        System.out.println(randomNum);
        System.out.println("Enter a number from 0 to 100:");
        int userNum;
        int count = 0;
        int sum = 0;
      int sumSquares = 0;
      String username;

        while (true) {
            try {
                userNum = input1.nextInt();
                sum += userNum;
                sumSquares += userNum * userNum;
                count++;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number:");
                input1.next(); // Clear the invalid input
                continue;
            }

            if (randomNum == userNum) {
                System.out.println("Congratulations!");

                break;
            } else if (userNum < randomNum) {
                System.out.println("Guess a larger number:");

            } else {
                System.out.println("Guess a smaller number:");

            }
        }
        System.out.println("Enter the user name:");
        username = input1.next();


        double mean = (double) sum / count;
        double variance = (double) sumSquares / count - mean * mean;
        double stdDev = Math.sqrt(variance);

        try {
            FileWriter writer = new FileWriter("GuessReport.txt",true);
            PrintWriter user1 = new PrintWriter(writer);
            user1.printf("\nTHE USER NAME: \n"+username);
            user1.println("\nTHE NUMBER OF ATTEMPTS:\t");
            user1.print(count);
            user1.println();
            user1.println("\nTHE STANDARD DEVIATION:\t");
            user1.print(stdDev);
            user1.close();
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
